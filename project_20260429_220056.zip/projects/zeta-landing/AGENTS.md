# Zeta TikTok SaaS 系统

## 项目简介
Zeta Core - 全球首款TikTok一人外贸公司全自动化SaaS系统

## 技术栈
- Next.js 16 (App Router)
- React 19
- TypeScript 5
- Tailwind CSS 4
- pnpm

## 项目结构
```
zeta-landing/
├── src/
│   ├── app/
│   │   ├── page.tsx          # 主页面
│   │   ├── layout.tsx        # 布局
│   │   ├── globals.css       # 全局样式
│   │   └── api/             # API接口
│   │       ├── zeta/execute/ # 执行API
│   │       └── automation/   # 自动化API
├── public/
├── package.json
├── tsconfig.json
├── .coze
└── zeta-tiktok.tar.gz        # 打包文件
```

## 启动命令
```bash
# 安装依赖
pnpm install

# 安装tsx（必需）
pnpm add -D tsx

# 开发模式
pnpm dev

# 构建
pnpm build

# 生产模式
pnpm start
```

## 核心功能
1. Zeta Core 全局调度中枢 - 自然语言理解+全局记忆
2. 8个专业小龙虾智能体 - 各司其职，独立任务
3. 智能体协同工作 - 全局记忆互通
4. 对话式交互 - 听懂人话直接执行
5. OCP全流程 - Operation→Conversion→Prediction

## 智能体列表
1. 🦞 数据采集 - TikTok全平台数据采集
2. 🦞 爆款选品 - AI选品模型
3. 🦞 AI内容生产 - 脚本+视频+封面
4. 🦞 矩阵账号管理 - 养号+风控
5. 🦞 自动化发布 - 定时发布+小黄车
6. 🦞 互动运维 - 评论+私信
7. 🦞 投放转化 - Ads投放+ROI
8. 🦞 数据复盘 - 全链路分析

## 端口
- 开发模式：5000
- 生产模式：5000
