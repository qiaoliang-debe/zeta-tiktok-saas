import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Zeta 泽塔科技 | Intelligence Redefined",
    template: "%s | Zeta 泽塔科技",
  },
  description:
    "Zeta泽塔科技 - TikTok一人公司全自动化SaaS系统。Intelligence Redefined | 一人即TikTok帝国。",
  keywords: [
    "Zeta",
    "泽塔科技",
    "TikTok",
    "SaaS",
    "智能体",
    "自动化",
    "选品",
    "内容生产",
    "矩阵管理",
  ],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "Zeta 泽塔科技 | Intelligence Redefined",
    description: "TikTok一人公司全自动化SaaS系统 | 一人即TikTok帝国",
    type: "website",
  },
};

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" className="dark">
      <body className={`${inter.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  );
}
