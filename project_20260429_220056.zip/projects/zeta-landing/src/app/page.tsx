'use client';

import { useState, useRef, useEffect, useCallback } from 'react';

// ============ 类型定义 ============
interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  agent?: string;
  action?: 'execute' | 'suggest';
}

interface Agent {
  id: string;
  name: string;
  icon: string;
  status: 'online' | 'busy' | 'offline';
  description: string;
  usageCount: number;
  steps: string[];
}

interface ExecutionLog {
  id: string;
  step: number;
  agent: string;
  action: string;
  status: 'pending' | 'running' | 'completed';
  timestamp: Date;
}

// ============ 常量 ============
const AGENTS: Agent[] = [
  { id: 'zeta_core', name: 'Zeta Core', icon: '🤖', status: 'online', description: '全局调度中枢', usageCount: 0, steps: ['理解需求', '分配任务', '协同调度'] },
  { id: 'data', name: '数据采集', icon: '🦞', status: 'online', description: 'TikTok数据采集专家', usageCount: 0, steps: ['打开TikTok', '搜索关键词', '提取数据', '清洗整理'] },
  { id: 'product', name: '爆款选品', icon: '🦞', status: 'online', description: 'AI选品分析专家', usageCount: 0, steps: ['接收数据', 'AI评分', '竞品分析', '推荐报告'] },
  { id: 'content', name: 'AI内容', icon: '🦞', status: 'online', description: '内容生产专家', usageCount: 0, steps: ['分析卖点', '生成脚本', '制作封面', '输出成品'] },
  { id: 'account', name: '账号管理', icon: '🦞', status: 'online', description: '矩阵账号管理', usageCount: 0, steps: ['账号检测', '养号任务', '风控评估', '分配发布'] },
  { id: 'publish', name: '自动发布', icon: '🦞', status: 'online', description: '自动化发布专家', usageCount: 0, steps: ['制定计划', '上传视频', '挂载小黄车', '定时发布'] },
  { id: 'interaction', name: '互动运维', icon: '🦞', status: 'online', description: '互动运维专家', usageCount: 0, steps: ['监控评论', 'AI回复', '私信处理', '粉丝管理'] },
  { id: 'ads', name: '智能投放', icon: '🦞', status: 'online', description: '投放优化专家', usageCount: 0, steps: ['识别爆款', '创建计划', '智能出价', 'ROI优化'] },
  { id: 'report', name: '数据复盘', icon: '🦞', status: 'online', description: '全链路复盘专家', usageCount: 0, steps: ['聚合数据', '指标分析', '问题诊断', '策略建议'] },
];

// ============ AI对话引擎 ============
function processUserMessage(message: string, context: Message[]): { response: string; action?: 'execute' | 'suggest'; agent?: string } {
  const lowerMsg = message.toLowerCase();
  const ctxText = context.map(m => `${m.role}: ${m.content}`).join('\n');
  const ctxLower = ctxText.toLowerCase();
  
  // 理解用户意图
  const intents = {
    // 数据采集类
    isDataCollection: lowerMsg.includes('采集') || lowerMsg.includes('爬取') || lowerMsg.includes('数据') && (lowerMsg.includes('多少') || lowerMsg.includes('怎么样') || lowerMsg.includes('分析')),
    // 选品类
    isProductSelection: lowerMsg.includes('选品') || lowerMsg.includes('选') && (lowerMsg.includes('品') || lowerMsg.includes('款')),
    // 内容类
    isContentGeneration: lowerMsg.includes('内容') || lowerMsg.includes('视频') || lowerMsg.includes('脚本') || lowerMsg.includes('文案'),
    // 账号类
    isAccountManagement: lowerMsg.includes('账号') || lowerMsg.includes('矩阵'),
    // 发布类
    isPublishing: lowerMsg.includes('发布') || lowerMsg.includes('上传') || lowerMsg.includes('定时'),
    // 互动类
    isInteraction: lowerMsg.includes('评论') || lowerMsg.includes('私信') || lowerMsg.includes('粉丝'),
    // 投放类
    isAds: lowerMsg.includes('投放') || lowerMsg.includes('广告') || lowerMsg.includes('推广'),
    // 复盘类
    isReport: lowerMsg.includes('复盘') || lowerMsg.includes('报告') || lowerMsg.includes('数据'),
    // 执行确认
    isConfirm: lowerMsg.includes('执行') || lowerMsg.includes('开始') || lowerMsg.includes('做') || lowerMsg.includes('跑'),
    // 询问状态
    isStatusQuery: lowerMsg.includes('怎么样') || lowerMsg.includes('如何') || lowerMsg.includes('多少'),
    // 同行分析
    isCompetitorAnalysis: lowerMsg.includes('同行') || lowerMsg.includes('对标') || lowerMsg.includes('竞品'),
  };
  
  // 提取关键词
  let keyword = '';
  const keywords = ['铃鼓', '美妆', '家居', '服装', '3C', '玩具', '宠物', '户外', '厨房'];
  for (const kw of keywords) {
    if (lowerMsg.includes(kw)) {
      keyword = kw;
      break;
    }
  }
  
  // 如果上下文中有提到关键词
  if (!keyword && ctxLower.includes('铃鼓')) keyword = '铃鼓';
  if (!keyword && ctxLower.includes('美妆')) keyword = '美妆';
  if (!keyword && ctxLower.includes('家居')) keyword = '家居';
  
  // 分析意图
  let intent = 'general';
  let action: 'execute' | 'suggest' | undefined;
  let agent = 'zeta_core';
  
  if (isCompetitorAnalysis || isDataCollection) {
    intent = 'data_collection';
    agent = 'data';
    action = 'execute';
  } else if (isProductSelection) {
    intent = 'product_selection';
    agent = 'product';
    action = 'execute';
  } else if (isContentGeneration) {
    intent = 'content_generation';
    agent = 'content';
    action = 'execute';
  } else if (isAccountManagement) {
    intent = 'account_management';
    agent = 'account';
    action = 'execute';
  } else if (isPublishing) {
    intent = 'publishing';
    agent = 'publish';
    action = 'execute';
  } else if (isInteraction) {
    intent = 'interaction';
    agent = 'interaction';
    action = 'execute';
  } else if (isAds) {
    intent = 'ads';
    agent = 'ads';
    action = 'execute';
  } else if (isReport) {
    intent = 'report';
    agent = 'report';
    action = 'execute';
  }
  
  // 生成自然回复
  const agentName = AGENTS.find(a => a.id === agent)?.name || '系统';
  
  if (isConfirm) {
    return {
      response: `好的，正在${keyword ? `采集「${keyword}」` : '采集数据'}...`,
      action: 'execute',
      agent
    };
  }
  
  if (isStatusQuery) {
    // 用户询问"怎么样"，根据上下文理解问题
    if (keyword) {
      return {
        response: `「${keyword}」在TikTok表现不错！\n\n近7天数据：\n• 平均播放量：12.5万\n• 平均点赞：8,600\n• 互动率：6.8%\n• 预估日出单：50-80单\n\n需要我帮您采集详细数据吗？`,
        action: 'suggest',
        agent
      };
    }
    return {
      response: `目前系统运行正常，8个小龙虾智能体都在线待命。有什么需要我帮您的吗？`,
      action: undefined,
      agent: 'zeta_core'
    };
  }
  
  // 默认回复 - 直接执行相关任务
  if (action === 'execute') {
    const agentInfo = AGENTS.find(a => a.id === agent);
    return {
      response: `明白，我来帮您${intent === 'data_collection' ? '采集数据' : intent === 'product_selection' ? '分析选品' : '处理'}${keyword ? `「${keyword}」` : ''}的相关信息...\n\n正在调用「${agentInfo?.name}」小龙虾${agentInfo?.description}...`,
      action: 'execute',
      agent
    };
  }
  
  // 通用理解
  if (lowerMsg.includes('怎么') || lowerMsg.includes('如何') || lowerMsg.includes('做')) {
    if (keyword) {
      return {
        response: `${keyword}这个品类我建议这样操作：\n\n1. 先采集同行数据\n2. 分析爆款选品\n3. 生产内容\n4. 自动化发布\n\n需要我帮您开始执行吗？`,
        agent: 'zeta_core'
      };
    }
  }
  
  return {
    response: `好的，我明白了。请问您想要：\n\n1. 采集TikTok数据\n2. 分析选品\n3. 生成内容\n4. 其他需求\n\n直接告诉我您想做什么，我来执行。`,
    agent: 'zeta_core'
  };
}

// ============ 主组件 ============
export default function ZetaChatDashboard() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '您好！我是Zeta Core，TikTok一人公司创业SaaS系统的调度中枢。\n\n您想要做什么？直接告诉我，比如：\n• "帮我采集铃鼓的数据"\n• "分析美妆选品"\n• "看看同行竞品"\n\n我会直接帮您执行！',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [agents, setAgents] = useState(AGENTS);
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionLogs, setExecutionLogs] = useState<ExecutionLog[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const idCounterRef = useRef(1000);
  
  const generateId = () => `msg_${++idCounterRef.current}`;
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSendMessage = useCallback(() => {
    if (!inputValue.trim() || isExecuting) return;
    
    const userMessage: Message = {
      id: generateId(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    
    // 模拟思考
    setTimeout(() => {
      const result = processUserMessage(userMessage.content, messages);
      
      const aiMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: result.response,
        timestamp: new Date(),
        agent: result.agent,
        action: result.action
      };
      
      setMessages(prev => [...prev, aiMessage]);
      
      // 如果需要执行，弹出确认
      if (result.action === 'execute' || result.action === 'suggest') {
        setSelectedAgent(result.agent || 'zeta_core');
      }
    }, 500);
  }, [inputValue, isExecuting, messages]);
  
  const handleConfirmExecute = () => {
    const agent = agents.find(a => a.id === selectedAgent);
    if (!agent) return;
    
    setModalMessage(`正在执行「${agent.name}」小龙虾任务...`);
    setShowModal(true);
    setIsExecuting(true);
    
    // 更新使用次数
    setAgents(prev => prev.map(a => 
      a.id === selectedAgent ? { ...a, usageCount: a.usageCount + 1 } : a
    ));
    
    // 生成执行日志
    const logs: ExecutionLog[] = agent.steps.map((step, i) => ({
      id: generateId(),
      step: i + 1,
      agent: agent.name,
      action: step,
      status: 'pending',
      timestamp: new Date()
    }));
    setExecutionLogs(logs);
    
    // 逐步执行
    logs.forEach((log, i) => {
      setTimeout(() => {
        setExecutionLogs(prev => prev.map(l => 
          l.id === log.id ? { ...l, status: 'running' as const } : l
        ));
        
        setTimeout(() => {
          setExecutionLogs(prev => prev.map(l => 
            l.id === log.id ? { ...l, status: 'completed' as const } : l
          ));
          
          if (i === logs.length - 1) {
            setTimeout(() => {
              setShowModal(false);
              setIsExecuting(false);
              
              const completionMsg: Message = {
                id: generateId(),
                role: 'assistant',
                content: `✅ 「${agent.name}」任务执行完成！\n\n执行报告：\n• 总步骤：${logs.length}步\n• 成功率：100%\n• 耗时：${logs.length * 2}秒\n\n${agent.id === 'data' ? '已采集数据：50条视频、30个商品\n• 平均播放量：15.2万\n• 热门视频：播放68万、点赞4.2万' : 
                  agent.id === 'product' ? '已筛选爆品：5个\n• 推荐指数：⭐⭐⭐⭐⭐\n• 预估日出单：60-100单' : 
                  '任务已完成，请告诉我下一步指令。'}`,
                timestamp: new Date()
              };
              setMessages(prev => [...prev, completionMsg]);
            }, 1500);
          }
        }, 1500);
      }, 100);
    });
  };
  
  const handleQuickAction = (agentId: string) => {
    const agent = agents.find(a => a.id === agentId);
    if (!agent) return;
    
    const quickCommands: Record<string, string> = {
      data: '帮我采集TikTok数据',
      product: '帮我分析选品',
      content: '帮我生成内容',
      account: '检测账号状态',
      publish: '准备发布内容',
      interaction: '处理互动运维',
      ads: '优化广告投放',
      report: '生成数据报告',
    };
    
    setInputValue(quickCommands[agentId] || '执行任务');
    handleSendMessage();
  };
  
  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      backgroundColor: '#0a0e17',
      color: '#ffffff',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      {/* 左侧 - 智能体列表 */}
      <div style={{
        width: 280,
        borderRight: '1px solid rgba(255,255,255,0.1)',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {/* 标题 */}
        <div style={{ padding: 20, borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
            <span style={{ fontSize: 24 }}>🦞</span>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, color: '#00d4ff' }}>zeta-tiktok</div>
              <div style={{ fontSize: 11, color: '#666' }}>一人公司tk创业saas</div>
            </div>
          </div>
        </div>
        
        {/* 智能体列表 */}
        <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
          {agents.map(agent => (
            <div
              key={agent.id}
              onClick={() => setSelectedAgent(agent.id === selectedAgent ? null : agent.id)}
              style={{
                padding: 12,
                marginBottom: 8,
                borderRadius: 10,
                background: selectedAgent === agent.id ? 'rgba(0, 212, 255, 0.15)' : 'rgba(255,255,255,0.03)',
                border: selectedAgent === agent.id ? '1px solid rgba(0, 212, 255, 0.5)' : '1px solid rgba(255,255,255,0.05)',
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 20 }}>{agent.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
                    {agent.name}
                    <span style={{
                      fontSize: 9,
                      padding: '1px 5px',
                      borderRadius: 3,
                      background: agent.status === 'online' ? '#22c55e' : agent.status === 'busy' ? '#f59e0b' : '#666',
                      color: '#fff'
                    }}>
                      {agent.status === 'online' ? '在线' : agent.status === 'busy' ? '忙碌' : '离线'}
                    </span>
                  </div>
                  <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>{agent.description}</div>
                </div>
                {agent.usageCount > 0 && (
                  <span style={{ fontSize: 10, color: '#00d4ff' }}>{agent.usageCount}次</span>
                )}
              </div>
              {selectedAgent === agent.id && (
                <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                  <div style={{ fontSize: 10, color: '#666', marginBottom: 4 }}>执行流程：</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {agent.steps.map((step, i) => (
                      <span key={i} style={{
                        fontSize: 9,
                        padding: '2px 6px',
                        background: 'rgba(0,212,255,0.1)',
                        borderRadius: 3,
                        color: '#00d4ff'
                      }}>
                        {step}
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleQuickAction(agent.id); }}
                    style={{
                      marginTop: 8,
                      width: '100%',
                      padding: '6px 12px',
                      borderRadius: 6,
                      border: 'none',
                      background: 'linear-gradient(135deg, #00d4ff 0%, #0066ff 100%)',
                      color: '#fff',
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: 'pointer'
                    }}
                  >
                    一键执行
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
        
        {/* 底部状态 */}
        <div style={{ padding: 12, borderTop: '1px solid rgba(255,255,255,0.1)', fontSize: 11, color: '#666' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#22c55e' }} />
            8个小龙虾在线
          </div>
        </div>
      </div>
      
      {/* 中间 - 对话区域 */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* 头部 */}
        <div style={{
          padding: 16,
          borderBottom: '1px solid rgba(255,255,255,0.1)',
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }}>
          <span style={{ fontSize: 24 }}>🤖</span>
          <div>
            <div style={{ fontSize: 15, fontWeight: 600 }}>Zeta Core 调度中枢</div>
            <div style={{ fontSize: 11, color: '#666' }}>全局协同 · 智能调度 · 记忆互通</div>
          </div>
          {isExecuting && (
            <div style={{
              marginLeft: 'auto',
              padding: '4px 12px',
              borderRadius: 20,
              background: 'rgba(34, 197, 94, 0.2)',
              color: '#22c55e',
              fontSize: 12,
              display: 'flex',
              alignItems: 'center',
              gap: 6
            }}>
              <span style={{ animation: 'pulse 1s infinite' }}>●</span>
              执行中
            </div>
          )}
        </div>
        
        {/* 消息列表 */}
        <div style={{ flex: 1, overflow: 'auto', padding: 20 }}>
          {messages.map(msg => (
            <div key={msg.id} style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start',
              marginBottom: 16
            }}>
              {msg.role === 'assistant' && msg.agent && (
                <div style={{ fontSize: 10, color: '#00d4ff', marginBottom: 4 }}>
                  {AGENTS.find(a => a.id === msg.agent)?.icon} {AGENTS.find(a => a.id === msg.agent)?.name}
                </div>
              )}
              <div style={{
                maxWidth: '70%',
                padding: msg.role === 'user' ? '12px 16px' : '12px 16px',
                borderRadius: msg.role === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
                background: msg.role === 'user' 
                  ? 'linear-gradient(135deg, #00d4ff 0%, #0066ff 100%)'
                  : 'rgba(255,255,255,0.08)',
                fontSize: 13,
                lineHeight: 1.6,
                whiteSpace: 'pre-wrap'
              }}>
                {msg.content}
              </div>
              <div style={{ fontSize: 10, color: '#555', marginTop: 4 }}>
                {msg.timestamp.toLocaleTimeString("en-US", {hour12: false, timeZone: "UTC"})}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        {/* 输入区域 */}
        <div style={{
          padding: 16,
          borderTop: '1px solid rgba(255,255,255,0.1)'
        }}>
          <div style={{
            display: 'flex',
            gap: 10,
            background: 'rgba(255,255,255,0.05)',
            borderRadius: 24,
            padding: '4px 4px 4px 16px'
          }}>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="直接告诉我您想做什么..."
              style={{
                flex: 1,
                background: 'transparent',
                border: 'none',
                outline: 'none',
                color: '#fff',
                fontSize: 14
              }}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isExecuting}
              style={{
                padding: '8px 20px',
                borderRadius: 20,
                border: 'none',
                background: inputValue.trim() 
                  ? 'linear-gradient(135deg, #00d4ff 0%, #0066ff 100%)'
                  : 'rgba(255,255,255,0.1)',
                color: inputValue.trim() ? '#fff' : '#666',
                fontSize: 13,
                fontWeight: 600,
                cursor: inputValue.trim() ? 'pointer' : 'not-allowed'
              }}
            >
              发送
            </button>
          </div>
          <div style={{ marginTop: 8, fontSize: 10, color: '#555', textAlign: 'center' }}>
            直接说您想做什么，我会直接执行，不用选择
          </div>
        </div>
      </div>
      
      {/* 右侧 - 执行面板 */}
      <div style={{
        width: 320,
        borderLeft: '1px solid rgba(255,255,255,0.1)',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {/* OCP流程 */}
        <div style={{ padding: 16, borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>📋 OCP 全流程</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {['数据采集', '爆款选品', 'AI内容', '账号检测', '自动发布', '互动运维', '智能投放', '数据复盘'].map((step, i) => {
              const log = executionLogs.find(l => l.step === i + 1);
              const status = log?.status || 'pending';
              return (
                <div key={i} style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  fontSize: 12
                }}>
                  <span style={{
                    width: 20,
                    height: 20,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 10,
                    background: status === 'completed' ? '#22c55e' : status === 'running' ? '#3b82f6' : 'rgba(255,255,255,0.1)',
                    color: status === 'pending' ? '#666' : '#fff'
                  }}>
                    {status === 'completed' ? '✓' : i + 1}
                  </span>
                  <span style={{ color: status === 'pending' ? '#666' : '#fff' }}>{step}</span>
                  {status === 'running' && <span style={{ marginLeft: 'auto', fontSize: 10, color: '#3b82f6' }}>执行中...</span>}
                </div>
              );
            })}
          </div>
        </div>
        
        {/* 执行日志 */}
        <div style={{ flex: 1, overflow: 'auto', padding: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>📝 执行日志</div>
          {executionLogs.length === 0 ? (
            <div style={{ fontSize: 12, color: '#666', textAlign: 'center', padding: 20 }}>
              暂无执行记录
            </div>
          ) : (
            executionLogs.map(log => (
              <div key={log.id} style={{
                padding: 8,
                marginBottom: 6,
                borderRadius: 6,
                background: log.status === 'running' ? 'rgba(59, 130, 246, 0.1)' : 
                            log.status === 'completed' ? 'rgba(34, 197, 94, 0.1)' : 'transparent',
                border: `1px solid ${log.status === 'running' ? 'rgba(59, 130, 246, 0.3)' : 
                                      log.status === 'completed' ? 'rgba(34, 197, 94, 0.3)' : 'transparent'}`,
                fontSize: 11
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{
                    width: 6,
                    height: 6,
                    borderRadius: '50%',
                    background: log.status === 'completed' ? '#22c55e' : log.status === 'running' ? '#3b82f6' : '#666'
                  }} />
                  <span style={{ color: '#fff' }}>{log.action}</span>
                </div>
                <div style={{ color: '#666', marginTop: 2, fontSize: 10 }}>
                  {log.timestamp.toLocaleTimeString("en-US", {hour12: false})}
                </div>
              </div>
            ))
          )}
        </div>
        
        {/* 快捷操作 */}
        <div style={{ padding: 16, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <button
            onClick={handleConfirmExecute}
            disabled={!selectedAgent || isExecuting}
            style={{
              width: '100%',
              padding: '12px 16px',
              borderRadius: 10,
              border: 'none',
              background: selectedAgent && !isExecuting 
                ? 'linear-gradient(135deg, #00d4ff 0%, #0066ff 100%)'
                : 'rgba(255,255,255,0.1)',
              color: selectedAgent && !isExecuting ? '#fff' : '#666',
              fontSize: 13,
              fontWeight: 600,
              cursor: selectedAgent && !isExecuting ? 'pointer' : 'not-allowed'
            }}
          >
            {isExecuting ? '执行中...' : '▶ 确认执行'}
          </button>
        </div>
      </div>
      
      {/* 执行弹窗 */}
      {showModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: '#111827',
            borderRadius: 16,
            padding: 32,
            textAlign: 'center',
            maxWidth: 400
          }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🦞</div>
            <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8 }}>{modalMessage}</div>
            <div style={{ fontSize: 12, color: '#666' }}>请稍候，正在执行中...</div>
            <div style={{
              marginTop: 16,
              height: 4,
              background: 'rgba(255,255,255,0.1)',
              borderRadius: 2,
              overflow: 'hidden'
            }}>
              <div style={{
                height: '100%',
                width: '30%',
                background: 'linear-gradient(90deg, #00d4ff, #0066ff)',
                borderRadius: 2,
                animation: 'loading 1.5s ease-in-out infinite'
              }} />
            </div>
          </div>
        </div>
      )}
      
      {/* 动画样式 */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }
      `}</style>
    </div>
  );
}
