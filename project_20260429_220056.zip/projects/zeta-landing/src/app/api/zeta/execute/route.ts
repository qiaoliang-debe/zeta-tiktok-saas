import { NextRequest, NextResponse } from "next/server";
import { LLMClient, Config, HeaderUtils } from "coze-coding-dev-sdk";

export async function POST(request: NextRequest) {
  try {
    const { action, params } = await request.json();
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    let result = "";

    switch (action) {
      case "data_collection": {
        // 数据采集 - 小龙虾爬虫集群
        const keywords = params.keywords || "TikTok爆款";
        const count = params.count || 10;
        const messages = [
          {
            role: "system",
            content: "你是一个专业的TikTok电商数据分析师，负责分析爆款商品趋势。请用JSON格式返回分析结果。"
          },
          {
            role: "user",
            content: `请分析当前TikTok上关于"${keywords}"的爆款趋势，返回${count}个最具潜力的商品数据，格式如下：\n[\n  {\n    "商品名称": "...",\n    "价格区间": "...",\n    "销量趋势": "...",\n    "竞争程度": "高/中/低",\n    "建议理由": "...",\n    "预估利润率": "..."\n  }\n]`
          }
        ];
        
        const stream = client.stream(messages, { 
          model: "doubao-seed-2-0-lite-260215",
          temperature: 0.7 
        });
        
        for await (const chunk of stream) {
          if (chunk.content) {
            result += chunk.content.toString();
          }
        }
        break;
      }

      case "product_selection": {
        // 爆款选品 - AI选品分析
        const product = params.product || "";
        const messages = [
          {
            role: "system",
            content: "你是一个专业的TikTok选品专家，精通侵权检测、利润测算和市场分析。"
          },
          {
            role: "user",
            content: `请对以下商品进行全面的TikTok选品分析：${product}\n\n分析维度：\n1. 侵权风险检测\n2. 利润空间测算\n3. 市场竞争分析\n4. 供应链建议\n5. 达人合作策略\n\n请以专业的电商分析师角度给出详细报告。`
          }
        ];

        const stream = client.stream(messages, {
          model: "doubao-seed-2-0-pro-260215",
          temperature: 0.7
        });

        for await (const chunk of stream) {
          if (chunk.content) {
            result += chunk.content.toString();
          }
        }
        break;
      }

      case "content_generation": {
        // AI内容生产 - 脚本生成
        const product = params.product || "";
        const style = params.style || "种草安利";
        const messages = [
          {
            role: "system",
            content: "你是一个专业的TikTok短视频脚本创作专家，擅长创作具有病毒传播潜力的带货视频脚本。"
          },
          {
            role: "user",
            content: `请为以下商品创作一个TikTok短视频带货脚本：\n\n商品：${product}\n风格：${style}\n\n要求：\n1. 前3秒必看钩子（制造悬念/冲突/反差）\n2. 中间产品展示（痛点+解决方案）\n3. 结尾CTA（行动号召）\n4. 配合字幕和配音提示\n5. 时长控制在30-60秒\n\n请输出完整的分镜头脚本。`
          }
        ];

        const stream = client.stream(messages, {
          model: "doubao-seed-2-0-pro-260215",
          temperature: 0.9
        });

        for await (const chunk of stream) {
          if (chunk.content) {
            result += chunk.content.toString();
          }
        }
        break;
      }

      case "account_analysis": {
        // 矩阵账号管理 - 账号健康分析
        const accountInfo = params.account || "账号矩阵";
        const messages = [
          {
            role: "system",
            content: "你是一个TikTok账号矩阵管理专家，精通账号风控、权重评估和养号策略。"
          },
          {
            role: "user",
            content: `请分析以下TikTok账号矩阵的健康状况：\n${accountInfo}\n\n分析维度：\n1. 账号状态评估（正常/限流/封禁风险）\n2. 权重分数分析（1-100）\n3. 风控风险预警\n4. 养号建议\n5. 内容优化策略\n\n请给出详细的诊断报告和改进建议。`
          }
        ];

        const stream = client.stream(messages, {
          model: "doubao-seed-2-0-lite-260215",
          temperature: 0.7
        });

        for await (const chunk of stream) {
          if (chunk.content) {
            result += chunk.content.toString();
          }
        }
        break;
      }

      case "data_review": {
        // 数据复盘 - 全局分析
        const period = params.period || "今日";
        const messages = [
          {
            role: "system",
            content: "你是一个专业的TikTok电商数据分析师，擅长数据聚合、问题诊断和策略优化。"
          },
          {
            role: "user",
            content: `请对${period}的TikTok运营数据进行全面复盘分析：\n\n分析维度：\n1. 核心数据概览（播放量、涨粉、GMV、转化率）\n2. 内容表现分析\n3. 问题诊断\n4. 策略优化建议\n5. 财务核算\n\n请给出专业的运营复盘报告。`
          }
        ];

        const stream = client.stream(messages, {
          model: "doubao-seed-2-0-pro-260215",
          temperature: 0.7
        });

        for await (const chunk of stream) {
          if (chunk.content) {
            result += chunk.content.toString();
          }
        }
        break;
      }

      default:
        return NextResponse.json({ error: "未知操作类型" }, { status: 400 });
    }

    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json({ 
      error: "服务暂不可用，请稍后重试",
      details: error instanceof Error ? error.message : "Unknown error"
    }, { status: 500 });
  }
}
